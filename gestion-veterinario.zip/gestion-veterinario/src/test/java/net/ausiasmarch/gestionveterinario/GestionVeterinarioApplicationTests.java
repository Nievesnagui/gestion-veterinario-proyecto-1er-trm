package net.ausiasmarch.gestionveterinario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionVeterinarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
